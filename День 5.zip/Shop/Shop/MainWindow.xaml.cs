﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Shop.pages;

namespace Shop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int error = 0;
        DateTime now = DateTime.Now;//текущие дата и время

        private void BtnAuthorization_Click(object sender, RoutedEventArgs e)//Авторизация
        {
            try
            {
                string forPasswordtxt = "";
                if (PbPasswordUser.Visibility == Visibility.Visible)
                {
                    forPasswordtxt = PbPasswordUser.Password;
                }
                else
                {
                    if (TbPasswordUser.Visibility == Visibility.Visible)
                    {
                        forPasswordtxt = TbPasswordUser.Text;
                    }
                }

                var forTypeUsers = App.shopEntities.Users.FirstOrDefault(x => x.Login == TbLoginUser.Text & x.Password == forPasswordtxt);//для входа
                if (TbLoginUser.Text == "" | forPasswordtxt == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    if (forTypeUsers != null)
                    {
                        switch (forTypeUsers.id_Role)
                        {
                            case 1://Администратор
                                Administrator administrator = new Administrator();
                                administrator.Show();
                                this.Close();
                                break;

                            case 2://Клиент
                                Client client = new Client();
                                client.Show();
                                this.Close();
                                break;

                            case 3://Менеджер
                                Manager manager = new Manager();
                                manager.Show();
                                this.Close();
                                break;
                        }
                    }
                    else
                    {
                        if (forTypeUsers == null)
                        {
                            error++;
                            MessageBox.Show("Данного пользователя не существует!\nПроверьте правильность введнных вами данных!",
                                "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                            if (error == 1)
                            {
                                Captcha captcha = new Captcha();
                                captcha.ShowDialog();
                                error = 0;
                            }
                        }
                    }
                }
            }
            catch { }
        }

        private void BtnOpenListProduct_Click(object sender, RoutedEventArgs e)//Вход под гостем
        {
            Client client = new Client();
            client.Show();
            this.Close();
        }

        int clickPassword = 0;
        private void BtnOpenORClosePassword_Click(object sender, RoutedEventArgs e)//Скрытие и открытие пароля
        {
            clickPassword++;
            if (clickPassword == 1)
            {
                BtnOpenORClosePassword.Content = "🔓";
                string passwordUsertxt = PbPasswordUser.Password;
                TbPasswordUser.Text = passwordUsertxt;
                PbPasswordUser.Visibility = Visibility.Hidden;
                TbPasswordUser.Visibility = Visibility.Visible;
            }
            else
            {
                clickPassword = 0;
                BtnOpenORClosePassword.Content = "🔒";
                string passwordUsertxt = TbPasswordUser.Text;
                PbPasswordUser.Password = passwordUsertxt;
                PbPasswordUser.Visibility = Visibility.Visible;
                TbPasswordUser.Visibility = Visibility.Hidden;
            }
        }

        int stop = 10;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        public void StartTimer()//После окончания таймера у Лаборанта
        {
            TbLoginUser.IsEnabled = false;
            PbPasswordUser.IsEnabled = false;
            TbPasswordUser.IsEnabled = false;
            BtnAuthorization.IsEnabled = false;
            BtnOpenORClosePassword.IsEnabled = false;
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
        }

        private void timerTick(object sender, EventArgs e)//Когда время вышло
        {
            if (stop == 0)
            {
                TbLoginUser.IsEnabled = true;
                PbPasswordUser.IsEnabled = true;
                TbPasswordUser.IsEnabled = true;
                BtnAuthorization.IsEnabled = true;
                BtnOpenORClosePassword.IsEnabled = true;
                MessageBoxResult result1 = MessageBox.Show("Время вышло!\nВойдите в систему заново!",
                    "Информация!", MessageBoxButton.OK, MessageBoxImage.Information);
                timer.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }
    }
}
