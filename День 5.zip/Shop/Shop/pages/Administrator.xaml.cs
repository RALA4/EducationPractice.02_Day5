﻿using Shop.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.pages
{
    /// <summary>
    /// Логика взаимодействия для Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        private Product[] products;
        private int totalCount;
        private int currentCount;
        public Administrator()
        {
            InitializeComponent();
            BaseProduct.ItemsSource = App.shopEntities.Products.ToList();
            cbFiltering.ItemsSource = App.shopEntities.Manufacturers.Select(x=>x.Name).ToList();
        }

        private Product[] SortProduct(Product[] product)//Сортировка
        {
            try
            {
                if (cbSorting.SelectedIndex == 0)
                    product = product.ToArray();
                if (cbSorting.SelectedIndex == 1)
                    product = product.OrderBy(c => c.Cost).ToArray();//по возрастанию
                if (cbSorting.SelectedIndex == 2)
                    product = product.
                        OrderByDescending(c => c.Cost).ToArray();//по убыванию
            }
            catch { }
            return product;
        }

        private Product[] FilterProduct(Product[] product)//Фильтрация
        {
            try
            {
                if (cbFiltering.SelectedIndex == 0)
                    product = product.ToArray();
                if (cbFiltering.SelectedIndex == 1)
                    product = product.Where(c => c.Manufacturer
                    .Name == "БТК Текстиль").ToArray();
                if (cbFiltering.SelectedIndex == 2)
                    product = product.Where(c => c.Manufacturer
                    .Name == "Империя ткани").ToArray();
                if (cbFiltering.SelectedIndex == 3)
                    product = product.Where(c => c.Manufacturer
                    .Name == "Комильфо").ToArray();
                if (cbFiltering.SelectedIndex == 4)
                    product = product.Where(c => c.Manufacturer
                    .Name == "Май Фабрик").ToArray();
            }
            catch { }
            return product;
        }
        private Product[] SearchProduct(Product[] product)//Поиск
        {
            try
            {
                if (tbSearch.Text != null)
                {
                    product = product.Where(c => c.Name.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                    c.ArticleNumber.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                     c.Description.ToLower().
                    Contains(tbSearch.Text.ToLower()) |
                     c.Manufacturer.Name.ToLower().
                    Contains(tbSearch.Text.ToLower())).ToArray();
                }
                if (product.Length == 0)
                {
                    BaseProduct.ItemsSource = product;
                    MessageBox.Show("Товаров с таким данными не найдено");
                }
            }
            catch { }

            return product;
        }
        private void RefreshData()//Вывод данных
        {

            products = App.shopEntities.Products.ToArray();
            products = SortProduct(products);
            products = FilterProduct(products);
            products = SearchProduct(products);
            BaseProduct.ItemsSource = products.ToList();
            totalCount = App.shopEntities.Products.Count();
            currentCount = products.Count();
            
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void cbFiltering_SelectionChanged(object sender, SelectionChangedEventArgs e)//Фильтрация
        {
            RefreshData();
        }

        private void cbSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)//Сортировка
        {
            RefreshData();
        }

        private void Search_SelectionChanged(object sender, RoutedEventArgs e)//Поиск
        {
            RefreshData();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)//Удаление
        {
            try
            {
                var row = BaseProduct.SelectedItem as database.Product;
                if (row == null)
                {
                    MessageBox.Show("Строка не выделена для удаления!");
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены что хотите удалить данную строку?", 
                        "Удаление!", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        App.shopEntities.Products.Remove(row);
                        App.shopEntities.SaveChanges();
                        Administrator administrator = new Administrator();
                        administrator.Show();
                        this.Close();
                    }
                }
            }
            catch { }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            AddProduct addProduct = new AddProduct();
            addProduct.Show();
            this.Close();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var row = BaseProduct.SelectedItem as database.Product;
            if (row == null)
            {
                MessageBox.Show("Строка не выделена для удаления!");
            }
            else
            {
                EditProduct editProduct = new EditProduct(row);
                editProduct.Show();
                this.Close();
            }
        }
    }
}
