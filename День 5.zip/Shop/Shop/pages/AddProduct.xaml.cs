﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.pages
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        public AddProduct()
        {
            InitializeComponent();
            cbCategory.ItemsSource = App.shopEntities.Categories.Select(x=>x.CategoryProduct).ToList();
            cbManufacturer.ItemsSource = App.shopEntities.Manufacturers.Select(x=>x.Name).ToList();
            cbUnitOfMeasurement.ItemsSource = App.shopEntities.UnitOfMeasurements.Select(x=>x.UnitOfMeasurement1).ToList();
            cbSupplier.ItemsSource = App.shopEntities.Suppliers.Select(x=>x.Suppliers).ToList();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            Administrator administrator = new Administrator();
            administrator.Show();
            this.Close();
        }

        private void ForAddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbArticle.Text == "" | tbName.Text == "" | tbDescription.Text == "" | cbCategory.Text == "" | cbManufacturer.Text == ""
                    | tbCost.Text == "" | tbDescription.Text == "" | tbQuantityInStock.Text == "" | cbUnitOfMeasurement.Text == "" | tbMaxDiscount.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int categoryID = App.shopEntities.Categories.Where(x => x.CategoryProduct == cbCategory.Text).Select(x => x.idCategory).FirstOrDefault();
                    int manufacturerID = App.shopEntities.Manufacturers.Where(x => x.Name == cbManufacturer.Text).Select(x => x.idManufacturer).FirstOrDefault();
                    int unitOfMeasurementID = App.shopEntities.UnitOfMeasurements.Where(x => x.UnitOfMeasurement1 == cbUnitOfMeasurement.Text).Select(x => x.idUnitOfManufacturer).FirstOrDefault();
                    int suppliersID = App.shopEntities.Suppliers.Where(x => x.Suppliers == cbSupplier.Text).Select(x => x.idSuppliers).FirstOrDefault();
                    database.Product product = new database.Product()
                    {
                        ArticleNumber = tbArticle.Text,
                        Name = tbName.Text,
                        Description = tbDescription.Text,
                        id_Category = categoryID,
                        id_Manufacturer = manufacturerID,
                        Cost = Convert.ToDecimal(tbCost.Text),
                        DiscountAmount = Convert.ToInt32(tbDiscount.Text),
                        QuantityInStock = Convert.ToInt32(tbQuantityInStock.Text),
                        id_UnitOfMeasurement = unitOfMeasurementID,
                        MaximumDiscount = Convert.ToInt32(tbMaxDiscount.Text),
                        id_Suppliers = suppliersID
                    };
                    App.shopEntities.Products.Add(product);
                    App.shopEntities.SaveChanges();
                    MessageBox.Show("Данные успешно добавлены!");
                    Administrator administrator = new Administrator();
                    administrator.Show();
                    this.Close();
                }

            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }
    }
}
