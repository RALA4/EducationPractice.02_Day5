﻿using Shop.database;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.pages
{
    /// <summary>
    /// Логика взаимодействия для EditProduct.xaml
    /// </summary>
    public partial class EditProduct : Window
    {
        database.Product product;
        public EditProduct(database.Product product)
        {
            InitializeComponent();
            cbCategory.ItemsSource = App.shopEntities.Categories.Select(x => x.CategoryProduct).ToList();
            cbManufacturer.ItemsSource = App.shopEntities.Manufacturers.Select(x => x.Name).ToList();
            cbUnitOfMeasurement.ItemsSource = App.shopEntities.UnitOfMeasurements.Select(x => x.UnitOfMeasurement1).ToList();
            cbSupplier.ItemsSource = App.shopEntities.Suppliers.Select(x => x.Suppliers).ToList();
            this.product = product;
            this.DataContext = product;
            identity = product.idProduct;
            List<Product> products = App.shopEntities.Products.Where(x=>x.idProduct == identity).ToList();
            
        }
        int identity;
        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            Administrator administrator = new Administrator();
            administrator.Show();
            this.Close();
        }

        private void ForEditProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbArticle.Text == "" | tbName.Text == "" | tbDescription.Text == "" | cbCategory.Text == "" | cbManufacturer.Text == ""
                    | tbCost.Text == "" | tbDescription.Text == "" | tbQuantityInStock.Text == "" | cbUnitOfMeasurement.Text == "" | tbMaxDiscount.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int categoryID = App.shopEntities.Categories.Where(x => x.CategoryProduct == cbCategory.Text).Select(x => x.idCategory).FirstOrDefault();
                    int manufacturerID = App.shopEntities.Manufacturers.Where(x => x.Name == cbManufacturer.Text).Select(x => x.idManufacturer).FirstOrDefault();
                    int unitOfMeasurementID = App.shopEntities.UnitOfMeasurements.Where(x => x.UnitOfMeasurement1 == cbUnitOfMeasurement.Text).Select(x => x.idUnitOfManufacturer).FirstOrDefault();
                    int suppliersID = App.shopEntities.Suppliers.Where(x => x.Suppliers == cbSupplier.Text).Select(x => x.idSuppliers).FirstOrDefault();

                    List<Product> products = App.shopEntities.Products.Where(x => x.idProduct == identity).ToList();
                    try
                    {
                        products[0].ArticleNumber = tbArticle.Text;
                        products[0].Name = tbName.Text;
                        products[0].Description = tbDescription.Text;
                        products[0].id_Category = categoryID;
                        products[0].id_Manufacturer = manufacturerID;
                        products[0].Cost = Convert.ToDecimal(tbCost.Text);
                        products[0].DiscountAmount = Convert.ToInt32(tbDiscount.Text);
                        products[0].QuantityInStock = Convert.ToInt32(tbQuantityInStock.Text);
                        products[0].id_UnitOfMeasurement = unitOfMeasurementID;
                        products[0].MaximumDiscount = Convert.ToInt32(tbMaxDiscount.Text);
                        products[0].id_Suppliers = suppliersID;
                    }
                    catch { }
                    App.shopEntities.Products.AddOrUpdate();
                    App.shopEntities.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    Administrator administrator = new Administrator();
                    administrator.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }
    }
}
